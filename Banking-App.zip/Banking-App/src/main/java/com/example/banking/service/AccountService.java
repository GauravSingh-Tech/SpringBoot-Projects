package com.example.banking.service;

import com.example.banking.entity.Account;
import com.example.banking.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {
	@Autowired
	    private AccountRepository accountRepository;

	    public Account createAccount(Account account) {
	        return accountRepository.save(account);
	    }

	    public List<Account> getAllAccounts() {
	        return accountRepository.findAll();
	    }

	    public Account addMoney(Long accountId, double amount) {
	        Account account = accountRepository.findById(accountId).orElseThrow();
	        account.setBalance(account.getBalance() + amount);
	        return accountRepository.save(account);
	    }

	    public Account withdrawMoney(Long accountId, double amount) {
	        Account account = accountRepository.findById(accountId).orElseThrow();
	        account.setBalance(account.getBalance() - amount);
	        return accountRepository.save(account);
	    }

	    public void deleteAccount(Long accountId) {
	        accountRepository.deleteById(accountId);
	    }
}
