package com.example.banking.service;

import com.example.banking.entity.Transaction;
import com.example.banking.util.PdfGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PdfService {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private PdfGenerator pdfGenerator;

    public byte[] generateTransactionStatementPdf(Long accountId, int days) {
        List<Transaction> transactions = transactionService.getTransactionsForAccount(accountId, days);
        return pdfGenerator.generateTransactionStatement(transactions);
    }
}
