package com.example.banking.service;

import com.example.banking.entity.Account;
import com.example.banking.entity.Transaction;
import com.example.banking.repository.AccountRepository;
import com.example.banking.repository.TransactionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

@Service
public class TransactionService {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private TransactionRepository transactionRepository;

	@Transactional
	public void transferMoney(Long fromAccountId, Long toAccountId, double amount) {
		// Find sender and receiver accounts
		Account fromAccount = accountRepository.findById(fromAccountId)
				.orElseThrow(() -> new RuntimeException("Sender account not found"));
		Account toAccount = accountRepository.findById(toAccountId)
				.orElseThrow(() -> new RuntimeException("Receiver account not found"));

		// Check if the sender has sufficient balance
		if (fromAccount.getBalance() < amount) {
			throw new RuntimeException("Insufficient balance");
		}

		// Deduct amount from sender's account
		fromAccount.setBalance(fromAccount.getBalance() - amount);
		accountRepository.save(fromAccount);

		// Add amount to receiver's account
		toAccount.setBalance(toAccount.getBalance() + amount);
		accountRepository.save(toAccount);

		// Create and save transaction record
		Transaction transaction = new Transaction();
		transaction.setFromAccountId(fromAccountId);
		transaction.setToAccountId(toAccountId);
		transaction.setAmount(amount);
		transactionRepository.save(transaction);
	}

	public List<Transaction> getTransactionsForAccount (Long accountId, int days) { LocalDateTime fromDate = LocalDateTime.now().minusDays (days);

    return transactionRepository.findByFromAccountIdOrToAccountId(accountId, accountId).stream().filter(t -> t.getTransactionDate().isAfter(fromDate)).toList();

    }
}
