package com.example.banking.dto;

public class PdfRequest {
    private Long accountId;
    private int days; // 1, 3, 7, 15, 30
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
}

