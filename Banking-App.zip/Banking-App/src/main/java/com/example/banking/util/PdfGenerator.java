package com.example.banking.util;

import com.example.banking.entity.Transaction;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class PdfGenerator {

    public byte[] generateTransactionStatement(List<Transaction> transactions) {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Title
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK);
            Paragraph title = new Paragraph("Transaction Statement", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            // Date formatting
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

            // Adding transactions to the document
            for (Transaction transaction : transactions) {
                Paragraph paragraph = new Paragraph(
                    "Transaction ID: " + transaction.getId() + "\n" +
                    "From Account ID: " + transaction.getFromAccountId() + "\n" +
                    "To Account ID: " + transaction.getToAccountId() + "\n" +
                    "Amount: " + transaction.getAmount() + "\n" +
                    "Date: " + transaction.getTransactionDate().format(formatter) + "\n\n"
                );
                document.add(paragraph);
            }

            document.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        }

        return out.toByteArray();
    }
}

