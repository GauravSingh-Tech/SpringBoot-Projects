package com.example.banking.controller;

import com.example.banking.dto.PdfRequest;
import com.example.banking.dto.TransferRequest;
import com.example.banking.service.OtpService;
import com.example.banking.service.EmailService;
import com.example.banking.service.PdfService;
import com.example.banking.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private OtpService otpService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private PdfService pdfService;

    @PostMapping("/transfer")
    public void transferMoney(@RequestBody TransferRequest transferRequest) {
        if (otpService.verifyOtp(transferRequest.getEmail(), transferRequest.getOtp())) {
            transactionService.transferMoney(transferRequest.getFromAccountId(), transferRequest.getToAccountId(), transferRequest.getAmount());
        } else {
            throw new RuntimeException("Invalid OTP");
        }
    }

    @PostMapping("/statement")
    public ResponseEntity<ByteArrayResource> getTransactionStatement(@RequestBody PdfRequest pdfRequest) {
        byte[] pdfContent = pdfService.generateTransactionStatementPdf(pdfRequest.getAccountId(), pdfRequest.getDays());
        ByteArrayResource resource = new ByteArrayResource(pdfContent);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=transaction_statement.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .contentLength(pdfContent.length)
                .body(resource);
    }
}
