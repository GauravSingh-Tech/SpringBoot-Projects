package com.example.banking.controller;

import com.example.banking.dto.AccountDTO;
import com.example.banking.dto.AddMoneyRequest;
import com.example.banking.dto.OtpRequest;
import com.example.banking.dto.PdfRequest;
import com.example.banking.dto.TransferRequest;
import com.example.banking.dto.WithdrawRequest;
import com.example.banking.entity.Account;
import com.example.banking.service.AccountService;
import com.example.banking.service.OtpService;
import com.example.banking.service.PdfService;
import com.example.banking.service.TransactionService;
import com.example.banking.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	private AccountService accountService;

	@Autowired
	private OtpService otpService;

	@Autowired
	private EmailService emailService;

	@Autowired
	private TransactionService transactionService;

	@PostMapping("/create")
	public Account createAccount(@RequestBody AccountDTO accountDTO) {
		Account account = new Account();
		account.setName(accountDTO.getName());
		account.setEmail(accountDTO.getEmail());
		account.setBalance(accountDTO.getBalance());
		return accountService.createAccount(account);
	}

	@GetMapping("/all")
	public List<Account> getAllAccounts() {
		return accountService.getAllAccounts();
	}

	@PostMapping("/add-money")
	public Account addMoney(@RequestBody AddMoneyRequest addMoneyRequest) {
		return accountService.addMoney(addMoneyRequest.getAccountId(), addMoneyRequest.getAmount());
	}

	@PostMapping("/withdraw")
	public Account withdrawMoney(@RequestBody WithdrawRequest withdrawRequest) {
		if (otpService.verifyOtp(withdrawRequest.getEmail(), withdrawRequest.getOtp())) {
			return accountService.withdrawMoney(withdrawRequest.getAccountId(), withdrawRequest.getAmount());
		} else {
			throw new RuntimeException("Invalid OTP");
		}
	}

	@DeleteMapping("/delete")
	public void deleteAccount(@RequestBody Long accountId) {
		accountService.deleteAccount(accountId);
	}

	@Autowired
	private PdfService pdfService;

	@PostMapping("/transfer")
	public void transferMoney(@RequestBody TransferRequest transferRequest) {
		if (otpService.verifyOtp(transferRequest.getEmail(), transferRequest.getOtp())) {
			transactionService.transferMoney(transferRequest.getFromAccountId(), transferRequest.getToAccountId(),
					transferRequest.getAmount());
		} else {
			throw new RuntimeException("Invalid OTP");
		}
	}

	@PostMapping("/request-otp")
    public ResponseEntity<String> requestOtp(@RequestBody OtpRequest otpRequest) {
//    Adding this lines for verifying mail
//    Account account = accountService.getAccountById(otpRequest.getFromAccountId());

    String email = otpRequest.getEmail(); if(email == null || !email.contains("@") || !email.contains(".")) {
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid Email Address");
    }
    String otp = otpService.generateOtp (otpRequest.getEmail());
    emailService.sendOtpEmail(otpRequest.getEmail(), otp);
    return ResponseEntity.ok("OTP sent to your email");

    }

	@PostMapping("/statement")
	public ResponseEntity<ByteArrayResource> getTransactionStatement(@RequestBody PdfRequest pdfRequest) {
		byte[] pdfContent = pdfService.generateTransactionStatementPdf(pdfRequest.getAccountId(), pdfRequest.getDays());
		ByteArrayResource resource = new ByteArrayResource(pdfContent);

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=transaction_statement.pdf")
				.contentType(MediaType.APPLICATION_PDF)
				.contentLength(pdfContent.length)
				.body(resource);
	}
}
